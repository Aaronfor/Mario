<?php

include 'database_credentials.php';

$id = isset( $_GET['accion'] ) ? $_GET['accion'] : '';

switch ($id) {
	case 'Agregar':
		agregar();
		break;
	case 'leer':
		leer();
		break;
	case 'Actualizar':
		actualizar();
		break;
	
	default:
		# code...
		break;
}


function agregar(){
	global $conexion;
	$email=$_GET['email']; 
	$pass=$_GET['password']; 

	mysqli_query($conexion, "INSERT INTO user (id,email,password) VALUES (null,'$email','$pass')") 
	or die ( "Algo ha ido mal al insertar"); 

    echo "Datos insertados"; 
    header("location: ../index.php");
}

function leer(){
	global $conexion;
	$sum=0;
	$consulta = 'SELECT * from user';

	$result = $conexion->query($consulta);

	while($row = $result->fetch_array()){
		$rows[] = $row;
	}
	foreach($rows as $row){
		$sum++;
		echo "<tr>";
        echo    "<td>" . $row['id'] . "</td>";
        echo    "<td>" . $row['email'] .  "</td>";
        echo    "<td>" . $row['password'] . "</td>";
        echo     "<td>
        			<a href=\"./key.php?id=" . $row['id'] . "\" class=\"button radius tiny secondary\">Detalles</a>
                    <input class=\"button radius tiny secondary\" type=\"button\" name=\"eliminar\" value=\"eliminar\">
                </td>";
        echo "</tr>";
        
	}
	echo "<tr>";
    echo   "<td colspan=\"4\"><b>Total de registros: </b>" . $sum . "</td>";
    echo  "</tr>";
}

function consulta(){
	global $conexion;
	$id=$_GET['id']; 
	$consulta = "SELECT * from user WHERE id =$id ";
	if (!$resultado = $conexion->query($consulta)) {
    	exit;
	}
	$con = $resultado->fetch_assoc();
	return $con;
}

function actualizar(){
	global $conexion;
	$id=$_GET['id']; 
	echo $id;
	$email=$_GET['email']; 
	$pass=$_GET['password']; 
	mysqli_query($conexion, "UPDATE user SET email='$email', password='$password' Where id=='$id' ")
	or die ( "Algo ha ido mal al actualizar");

	echo "Datos insertados"; 
    header("location: ../index.php");

}










?>