<?php
define('DB_HOST', 'localhost');
define('DB_DATABASE', 'mario');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

global $conexion;
$conexion = mysqli_connect( DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE) 
or die ("No se ha podido conectar al servidor de Base de datos");
?>